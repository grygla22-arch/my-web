---
name: Afternoon by the Window
colors:
  surface: '#fbf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#fbf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ef'
  surface-container: '#efeeea'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e4e2de'
  on-surface: '#1b1c1a'
  on-surface-variant: '#4f453e'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f0ed'
  outline: '#81756d'
  outline-variant: '#d2c4bb'
  surface-tint: '#725947'
  primary: '#322011'
  on-primary: '#ffffff'
  primary-container: '#4a3525'
  on-primary-container: '#bb9d88'
  inverse-primary: '#e1c0aa'
  secondary: '#78583e'
  on-secondary: '#ffffff'
  secondary-container: '#fdd2b1'
  on-secondary-container: '#78583f'
  tertiary: '#3b1b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#5a2e03'
  on-tertiary-container: '#d69562'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#fedcc5'
  primary-fixed-dim: '#e1c0aa'
  on-primary-fixed: '#29180a'
  on-primary-fixed-variant: '#594231'
  secondary-fixed: '#ffdcc2'
  secondary-fixed-dim: '#e8be9f'
  on-secondary-fixed: '#2c1603'
  on-secondary-fixed-variant: '#5d4128'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#feb882'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6a3b0f'
  background: '#fbf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2de'
typography:
  headline-xl:
    fontFamily: Noto Serif
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Noto Serif
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1.25rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

### Brand Personality & Emotional Resonance
The brand captures the unhurried warmth of sunlight pouring onto a wooden bakery table at 3 PM. It feels neighborly, tactile, mindful, and reassuring. The digital experience is deliberate and peaceful—evoking the comforting scent of freshly baked sourdough, butter crusts, and hand-pulled espresso. It avoids cold tech tropes, harsh pure whites, and mechanical hyper-efficiency, opting instead for organic intimacy and handcrafted care.

### Design Movement: Tactile Minimalism with Editorial Warmth
This design system pairs the quiet restraint of Japanese and Nordic café aesthetics with delicate editorial accents. High whitespace, low visual noise, warm paper-toned backgrounds, and tactile touchpoints create an environment where product cards and daily bake stories feel like pages from an artisanal café journal.

## Colors

The color palette is derived directly from roasted coffee beans, parchment paper, rising dough, and warm daylight.

### Palette Roles
- **Primary (`#4A3525`)**: Roasted Espresso. Used for high-emphasis headlines, key navigational anchors, and primary tactile actions.
- **Secondary (`#8C6A4F`)**: Warm Walnut. Bridges strong headings and subtle text; used for category indicators, secondary iconography, and subtle accents.
- **Tertiary (`#C98A58`)**: Golden Crust. A toast-inspired amber accent reserved for subtle badges (e.g., "갓 구움 / Freshly Baked"), active highlights, and notification pips.
- **Neutral Canvas (`#FDFBF7`)**: Warm Milk / Flour Cream. The foundational surface background, removing the clinical glare of `#FFFFFF`.

### Functional & Surface Tiers
- **Surface Canvas**: `#FDFBF7` (main background layer)
- **Surface Muted / Paper Container**: `#F5EFEB` (card backgrounds, floating trays)
- **Surface Sunken / Ingredient Tray**: `#EADBC8` (inputs, chips, segmented selectors)
- **Text High Emphasis**: `#2A1E17` (deep dark roast)
- **Text Medium Emphasis**: `#6D5D53` (steamed mocha)
- **Text Low / Muted**: `#A19389` (warm dust grey)
- **Borders & Dividers**: `#E5DACF` with an optional 60% opacity for delicate hairline dividers.

## Typography

Typography balances evocative editorial poise with immediate utility.

- **Display & Headings (Noto Serif)**: Brings the rhythm of a handwritten recipe card or literary journal. Used for titles, bakery signature stories, and greeting sections. When paired with Korean type systems, it inherits graceful Myeongjo characteristics that soften the screen.
- **Body & Controls (Plus Jakarta Sans)**: Delivers friendly clarity, open apertures, and gentle geometric curves that match the soft bread aesthetic. Ensures high legibility on mobile screens for pricing, bread descriptions, allergy notices, and order management.
- **Rhythm & Flow**: Line-heights for body text are intentionally generous (1.55–1.62) to maintain a calming reading experience with clear separation between items.

## Layout & Spacing

### Mobile-First Layout Model
The layout adopts a flexible fluid single-column column spine on mobile devices, constrained within a centered 430px canvas for preview, extending into a balanced 8-column layout on tablet and 12-column layout on desktop viewports.

- **Mobile (< 640px)**: 1.25rem outer margin, 1rem gutter between horizontal carousels and multi-column menu lists. The top and bottom viewport edges provide generous safe zones to give imagery room to breathe.
- **Tablet (640px – 1024px)**: 2rem margin, 1.25rem gutter. Menu cards reflow into 2-column or 3-column asymmetric layouts.
- **Desktop (> 1024px)**: 2.5rem margin, 1.5rem gutter. Maximum content boundary capped at 1120px to preserve an intimate boutique atmosphere rather than an expansive enterprise dashboard.

### Spacing Rhythm
Empty space functions as visual rests, mimicking silent moments in a quiet café. Section transitions rely on `space-xl` or larger breathing room, while component internals use `space-sm` and `space-md` for balanced grouping.

## Elevation & Depth

This design system eschews synthetic, sharp digital dropshadows in favor of **Tonal Layering** and **Sunlight Ambient Diffusion**.

### Elevation Layers
- **Surface Level 0 (Base Canvas)**: `#FDFBF7` – The warm plaster countertop.
- **Surface Level 1 (Cards & Trays)**: `#F5EFEB` with a subtle hairline outline (`#E5DACF`, 0.75px). No shadow required in standard states.
- **Surface Level 2 (Floating Modals & Sheets)**: `#FDFBF7` elevated with an ultra-soft, diffused amber-tinted shadow: `box-shadow: 0 10px 30px -8px rgba(62, 39, 35, 0.08), 0 4px 12px -2px rgba(62, 39, 35, 0.04)`.
- **Surface Level 3 (Sticky Bottom Cart / Quick Bar)**: Blended frosted background using `rgba(253, 251, 247, 0.9)` paired with `backdrop-filter: blur(12px)` and a top border of `#EADBC8`.

## Shapes

The shape system expresses organic baked goods: rounded, pillowy, and gentle to touch.

- **Level 2 (Rounded)**: Base elements (inputs, standard buttons, alerts) utilize `0.5rem` (8px). Medium containers and item presentation cards scale to `1rem` (16px), while modal dialogs and bottom sheets resolve at `1.5rem` (24px).
- **Specialized Pill Shapes**: Status indicators, bread batch tags, and floating action chips adopt full pill geometry (`9999px`) to echo smooth river pebbles and wooden table markers.

## Components

### Buttons
- **Primary Action (e.g., '빵 담기 / Add to Tray')**: Filled with `#4A3525`, typography in `#FDFBF7` (Semi-bold), with `0.5rem` radius and `1rem` vertical padding. Hover/press shifts subtly to `#3A2719` with a gentle 0.98 scale compression.
- **Secondary Action (e.g., '오늘의 라인업 보기')**: Surface in `#F5EFEB`, border in `1px solid #D8C7B5`, text in `#4A3525`.
- **Text Button**: Subtle underlined or standalone link in `#8C6A4F` without containers, preserving clean editorial simplicity.

### Chips & Filter Tags
- Height: 36px. Border-radius: `9999px`.
- Inactive state: `#F5EFEB` background with `#6D5D53` text.
- Active state: `#4A3525` background with `#FDFBF7` text and subtle warm drop glow.

### Product & Story Cards
- Background: `#F5EFEB` or `#FFFFFF` over `#FDFBF7` canvas with smooth 16px corner curves.
- Image aspect ratio: 4:3 or 1:1, softly rounded with no jarring harsh borders.
- Badging: Floating badge at top-left (`#C98A58` background, `#FFFFFF` text, `label-sm`) indicating daily status such as "오후 2시 출고 (2 PM Batch)".

### Input Fields & Selectors
- Background: `#FDFBF7` framed by a warm outline `1px solid #E5DACF`.
- Focus state: Outline smoothly transitions to `#8C6A4F` with an ambient glow (`box-shadow: 0 0 0 3px rgba(140, 106, 79, 0.15)`).
- Placeholder text in `#A19389`.

### Selection Controls (Checkbox & Radio)
- Radios and checkmarks use `#4A3525` active fill with soft rounded accents. Unchecked state is bordered with `#C9B8A7` on an off-white field.

### Daily Line-up List Item
- Structured horizontal rows separated by a delicate dotted or faded border (`#E5DACF`).
- Highlights bread name in `headline-md` or `title-md`, accompanied by pricing, remaining quantity counters, and warming sensory notes (e.g., "천연 발효종, 구운 호두").